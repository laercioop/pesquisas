# Agregador Eleitoral 2026 — acervo local e modelo auditável

**Data de corte:** 16 de outubro de 2026. **Unidade:** votos percentuais válidos,
salvo quando especificado `totais`. O arquivo `pesquisas_2026.csv` é o banco primário
editável; não depende de uma conversa do ChatGPT.

## Arquivos
- `pesquisas_2026.csv`: 74 registros individuais (46 pesquisas de primeiro turno e 28 de segundo turno), com datas de campo, amostra, instituto, registro no TSE, percentuais publicados, base de apuração, brancos/nulos, indecisos quando disponíveis, método e fonte.
- `modelo_vies.py`: implementação do modelo em Python, apenas com biblioteca padrão.
- `construir_base.py`: transcrição inicial documentada que gerou a base.
- `primeiro_turno_calculado.csv`: normalização dos votos e erros individuais.
- `vies_institutos.csv`: última pesquisa comparável de cada instituto e efeito encolhido.
- `segundo_turno_calculado.csv`: todas as rodadas e suas correções; `ultimo_2t=1` indica pesquisa que entra no agregado corrente.
- `cenarios.csv` e `resultado_modelo.json`: resultados calculados.
- `agregador_eleitoral_2026_auditavel.xlsx`: painel, dados brutos, ambas as séries, vieses por instituto, segundo turno corrente, cenários e método. No Excel, `Painel!B7` muda a fração de transferência e recalcula os cenários (mantendo outros parâmetros).

## Como executar
Tenha Python 3 instalado. Extraia o ZIP, entre na pasta dos arquivos
e rode:

```bash
python modelo_vies.py --as-of 2026-10-16 --alpha 0.5 --shrink 0.25
```

Outros testes úteis:

```bash
python modelo_vies.py --as-of 2026-10-16 --alpha 0
python modelo_vies.py --as-of 2026-10-16 --alpha 1
python modelo_vies.py --as-of 2026-10-16 --alpha 0.5 --metodo-neutro
```

**Observação:** os comandos reescrevem os CSVs de resultados na pasta, sem
modificar `pesquisas_2026.csv`. Para mudar os dados, edite o CSV bruto, execute o
script e consulte os CSVs de saída. O Excel é um retrato de 16/10/2026; acrescer
novas linhas no CSV e recalcular no Python **não atualiza automaticamente as
linhas importadas do Excel**. O parâmetro alfa, porém, é dinâmico no Excel original.

## Definições matemáticas

Nas eleições de 4/10/2026, o resultado oficial utilizado foi 47,03% dos votos
válidos para Flávio e 45,16% para Lula. Portanto, a margem **Flávio − Lula**
foi **+1,87 ponto percentual**.

Para a última pesquisa comparável do instituto `i` no primeiro turno:

    margem_pesquisa_i = flavio_validos_i - lula_validos_i
    erro_i = 1.87 - margem_pesquisa_i

Peso da rodada na calibração:

    peso_i = 2 ** (-dias_ate_04_10/14) * sqrt(min(n_i, 4000)/2000) * fator_metodo_i

Fatores ilustrativos de método: presencial 1, telefone 0,9,
online 0,7, misto 0,85, não informado 0,75. São hipóteses,
não classificações empiricamente comprovadas de qualidade.

    erro_comum = sum(peso_i * erro_i) / sum(peso_i)
    erro_encolhido_i = erro_comum + shrink * (erro_i - erro_comum)
    flavio_2t_ajustado_i = flavio_2t_validos_i + alpha * erro_encolhido_i / 2
    lula_2t_ajustado_i = 100 - flavio_2t_ajustado_i

Padrões adotados: `alpha = 0.5` e `shrink = 0.25`.
Alfa é a hipótese de **quantos % do erro histórico da margem** ainda prevalecem
no segundo turno; não confundir com probabilidade de vitória. O efeito específico
de cada instituto sofre encolhimento, dado que há apenas um pleito de referência.

O agregado do segundo turno usa a última rodada **após a eleição** de cada
instituto, pesos de recência (meia-vida de 14 dias), amostra e método. A
Atlas com entrevistas iniciadas antes da eleição recebe desconto de
amostra mista temporal. Percentuais de dois candidatos são normalizados para
somarem 100%.

## Principais resultados com este banco (16/10/2026)

- Calibração: 13 institutos finais; erro comum ponderado de **+3,37 pp na margem**, comparado com **+4,07 pp** obtido no diálogo antigo pela média de seis pesquisas. Eles medem amostras e normalizações diferentes.
- Segundo turno, sem transferir erro: **Flávio 51,39% × Lula 48,61%**.
- Transferência de metade do erro (`alpha=0.5`): **Flávio 52,22% × Lula 47,78%**.
- Transferência integral (`alpha=1`): **Flávio 53,06% × Lula 46,94%**.
- Estes são **cenários condicionais**, não probabilidades de vitória.

## Proveniência e limitações

O histórico original em `Agregador eleitoral 2026.pdf` descreve o agregador,
a metodologia de ponderação e uma conta curta de erro de +4,07 pp de margem,
mas **não contém um script original completo salvo nem os bytes das planilhas
Excel anteriores**. O presente `modelo_vies.py` é uma **nova implementação
reprodutível** inspirada no histórico, não um resgate literal do código anterior.

Fonte principal para a transcrição das 46 rodadas históricas de primeiro turno
e parte das pesquisas de segundo turno:
https://e26.cog.ia.br/eleicoes/pesquisas?cargo=presidente

Outros resultados e documentos, inclusive:
https://www.tse.jus.br/comunicacao/noticias/2026/Outubro/flavio-bolsonaro-e-lula-vao-disputar-o-2o-turno-para-a-presidencia-da-republica
https://www.poder360.com.br/poderdata/pesquisa-poderdata-aya-leia-resultados-de-lula-e-flavio-no-2o-turno/
https://www.placardaspesquisas.com.br/presidente

As fontes estão vinculadas linha a linha ao banco bruto e aos CSVs calculados.
A transcrição é uma reconstrução preliminar e deve ser confrontada com os
relatórios originais de cada pesquisa e com os respectivos registros do TSE
antes de utilização acadêmica ou publicação.

**Cobertura:** as 46 pesquisas do primeiro turno compreendem agosto a outubro
de 2026. Não são todas as pesquisas do ano ou todas as pesquisas regionais.
Uma pesquisa sem a base necessária para conversão em votos válidos
fica registrada mas **não entra na calibração**, em vez de se imputar denominador.

O erro de uma pesquisa perto do dia da eleição combina possíveis efeitos
de instituto, não resposta, mudança tardia de preferência e comparecimento.
Não há identificação causal nem evidência de que ele se repetirá na mesma
magnitude no segundo turno. A Palver mudou sua calibração após o primeiro
turno; sua comparação requer cuidado adicional. Pesquisas de partidos,
candidatos, métodos e momentos distintos podem ter relações diferentes
entre erro de primeiro e segundo turno.

O modelo não calcula intervalos probabilísticos calibrados, nem probabilidades
de vitória. Altere alfa e fatores para testar a sensibilidade, não para
declarar que existe viés estável estabelecido.
